package com.techelevator;

public class Module1CodingAssessment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
