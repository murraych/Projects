dropdb -U postgres module3assessment
createdb -U postgres module3assessment
psql -U postgres -d module3assessment -f puppies.sql