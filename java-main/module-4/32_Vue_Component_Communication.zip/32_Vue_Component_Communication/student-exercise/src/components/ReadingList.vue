<template>
  <div class="book-container">

  </div>
</template>

<script>

export default {
    name: 'reading-list'
}
</script>

<style>
.book-container {
    display:flex;
    justify-content: space-evenly;
    flex-wrap: wrap;
}
</style>