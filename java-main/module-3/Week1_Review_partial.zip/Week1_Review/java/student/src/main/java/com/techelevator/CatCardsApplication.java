package com.techelevator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CatCardsApplication {

    public static void main(String[] args) {
        SpringApplication.run(CatCardsApplication.class, args);
    }

}
