package com.techelevator.services;

import com.techelevator.model.CatFact;

public interface CatFactService {

    CatFact getFact();
}
