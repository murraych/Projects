package com.techelevator.model;

public class CatPic {
	private String file;
	
	public String getFile() {
		return this.file;
	}
	public void setFile(String file) {
		this.file = file;
	}
}
