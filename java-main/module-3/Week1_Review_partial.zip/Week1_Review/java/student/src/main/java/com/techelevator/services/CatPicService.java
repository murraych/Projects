package com.techelevator.services;

import com.techelevator.model.CatPic;

public interface CatPicService {

    CatPic getPic();

}
